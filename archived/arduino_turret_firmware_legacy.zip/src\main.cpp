#include <Arduino.h>
#include <Servo.h>

const uint8_t STEP_PIN = 3;
const uint8_t DIR_PIN = 4;
const uint8_t EN_PIN = 5;
const uint8_t SERVO_PIN = 9;

const int TILT_MIN = 40;
const int TILT_MAX = 140;
const int TILT_HOME = 90;
const int MAX_PAN_STEPS_PER_COMMAND = 200;
const unsigned int STEP_PULSE_US = 700;

Servo tiltServo;
long panPosition = 0;
int tiltAngle = TILT_HOME;
String inputLine;

int clampInt(int value, int low, int high) {
  if (value < low) {
    return low;
  }
  if (value > high) {
    return high;
  }
  return value;
}

void enableStepper(bool enabled) {
  digitalWrite(EN_PIN, enabled ? LOW : HIGH);
}

void movePan(int requestedSteps) {
  int steps = clampInt(requestedSteps, -MAX_PAN_STEPS_PER_COMMAND, MAX_PAN_STEPS_PER_COMMAND);
  if (steps == 0) {
    Serial.println(F("OK PAN 0"));
    return;
  }

  digitalWrite(DIR_PIN, steps >= 0 ? HIGH : LOW);
  enableStepper(true);
  int count = abs(steps);
  for (int i = 0; i < count; i++) {
    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(STEP_PULSE_US);
    digitalWrite(STEP_PIN, LOW);
    delayMicroseconds(STEP_PULSE_US);
  }
  enableStepper(false);
  panPosition += steps;
  Serial.print(F("OK PAN "));
  Serial.println(steps);
}

void setTilt(int requestedAngle) {
  // Clamp tilt commands in firmware as a final guard against software tuning mistakes.
  tiltAngle = clampInt(requestedAngle, TILT_MIN, TILT_MAX);
  tiltServo.write(tiltAngle);
  Serial.print(F("OK TILT "));
  Serial.println(tiltAngle);
}

void homeTurret() {
  panPosition = 0;
  setTilt(TILT_HOME);
  Serial.println(F("OK HOME"));
}

void stopTurret() {
  enableStepper(false);
  Serial.println(F("OK STOP"));
}

void printStatus() {
  Serial.print(F("OK STATUS PAN "));
  Serial.print(panPosition);
  Serial.print(F(" TILT "));
  Serial.println(tiltAngle);
}

bool parseCommandValue(const String &line, const String &prefix, int &value) {
  if (!line.startsWith(prefix)) {
    return false;
  }
  String valueText = line.substring(prefix.length());
  valueText.trim();
  if (valueText.length() == 0) {
    return false;
  }
  value = valueText.toInt();
  return true;
}

void handleCommand(String line) {
  line.trim();
  line.toUpperCase();
  if (line.length() == 0) {
    return;
  }

  int value = 0;
  if (parseCommandValue(line, F("PAN "), value)) {
    movePan(value);
  } else if (parseCommandValue(line, F("TILT "), value)) {
    setTilt(value);
  } else if (line == F("HOME")) {
    homeTurret();
  } else if (line == F("STOP")) {
    stopTurret();
  } else if (line == F("STATUS")) {
    printStatus();
  } else {
    Serial.print(F("ERR UNKNOWN_COMMAND "));
    Serial.println(line);
  }
}

void setup() {
  pinMode(STEP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(EN_PIN, OUTPUT);
  enableStepper(false);

  tiltServo.attach(SERVO_PIN);
  tiltServo.write(TILT_HOME);

  Serial.begin(115200);
  Serial.println(F("OK READY"));
}

void loop() {
  while (Serial.available() > 0) {
    char c = static_cast<char>(Serial.read());
    if (c == '\n' || c == '\r') {
      if (inputLine.length() > 0) {
        handleCommand(inputLine);
        inputLine = "";
      }
    } else if (inputLine.length() < 64) {
      inputLine += c;
    } else {
      // Drop oversized input instead of executing a partial or malformed command.
      inputLine = "";
      Serial.println(F("ERR COMMAND_TOO_LONG"));
    }
  }
}
